firewall-cmd --permanent --zone=public --add-port=28989/tcp
firewall-cmd --permanent --zone=public --add-port=28989/udp
firewall-cmd --permanent --zone=public --add-port=29000/tcp
firewall-cmd --permanent --zone=public --add-port=29000/udp
#
firewall-cmd --permanent --zone=public --add-port=29001/tcp

firewall-cmd --permanent --zone=public --add-port=29001/udp

firewall-cmd --permanent --zone=public --add-port=29002/tcp

firewall-cmd --permanent --zone=public --add-port=29002/udp

firewall-cmd --permanent --zone=public --add-port=29003/tcp

firewall-cmd --permanent --zone=public --add-port=29003/udp

firewall-cmd --permanent --zone=public --add-port=29004/tcp

firewall-cmd --permanent --zone=public --add-port=29004/udp

firewall-cmd --permanent --zone=public --add-port=29005/tcp

firewall-cmd --permanent --zone=public --add-port=29005/udp

firewall-cmd --permanent --zone=public --add-port=29006/tcp

firewall-cmd --permanent --zone=public --add-port=29006/udp

firewall-cmd --permanent --zone=public --add-port=29007/tcp

firewall-cmd --permanent --zone=public --add-port=29007/udp

firewall-cmd --permanent --zone=public --add-port=29008/tcp

firewall-cmd --permanent --zone=public --add-port=29008/udp

firewall-cmd --permanent --zone=public --add-port=29009/tcp

firewall-cmd --permanent --zone=public --add-port=29009/udp

firewall-cmd --permanent --zone=public --add-port=29010/tcp

firewall-cmd --permanent --zone=public --add-port=29010/udp

firewall-cmd --permanent --zone=public --add-port=38989/tcp

firewall-cmd --permanent --zone=public --add-port=38989/udp

firewall-cmd --reload