apache autoconf automake base-files busybox curl dnsmasq dropbear e2fsprogs firewall \
fstools fwtool ip6tables iptables jshn jsonfilter kernel \
lua luci luci-app-commands luci-app-firewall luci-app-privoxy luci-app-samba luci-base luci-i18n-base-zh-cn luci-i18n-firewall-zh-cn \
luci-i18n-privoxy-zh-cn luci-i18n-samba-zh-cn \
luci-ssl luci-theme-bootstrap m4 make mkf2fs mtd netifd odhcp6c odhcpd opkg partx-utils perl perlbase-attributes \
ppp ppp-mod-pppoe privoxy procd px5g-mbedtls r8169-firmware rpcd samba36-server ubox \
uhttpd uhttpd-mod-ubus unixodbc usign zlib 