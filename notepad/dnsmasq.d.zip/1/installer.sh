#!/bin/sh

# PACKAGE VARIABLES
PACKAGE="virtualbox"
NAME="VirtualBox"
TMP_DIR="${SYNOPKG_PKGDEST}/../../@tmp"
	
# COMMON PACKAGE VARIABLES
INSTALL_DIR="/usr/local/${PACKAGE}"
PACKAGE_DIR="/var/packages/${PACKAGE}"
WEB_DIR="/var/services/web"
DEFAULT_CFG_FILE_PHPVB="/usr/local/${PACKAGE}/www/config.php.synology"
CFG_FILE_PHPVB="${WEB_DIR}/phpvirtualbox/config.php"
DEFAULT_CFG_FILE_VB="/usr/local/${PACKAGE}/etc/vbox/vbox.cfg"
CFG_FILE_VB="/etc/vbox/vbox.cfg"
INSTALL_FILES="virtualbox_install_files"
BACKUP_FILES="virtualbox_backup_files"
KERNEL=$(uname -a | awk '{print $3}')
DIST=$(uname -a | awk '{print $14}')
LOADED_KERNEL_MODULE=$(lsmod | grep vboxdrv)
DSMMAJOR=$(get_key_value /etc.defaults/VERSION majorversion)
DSMMINOR=$(get_key_value /etc.defaults/VERSION minorversion)
DSMBUILD=$(get_key_value /etc.defaults/VERSION buildnumber)
# evansport only supports x86, so we need the x86 VBox Version
[ $(echo $DIST | grep evansport) ] && ARCH="x86" || ARCH="amd64"
	
# INCLUDE FUNCTIONS
. "$(dirname $0)"/lib.sh
	
# COMMON VIRTUALBOX VARIABLES
VIRTUALBOX_VER="5.0.14"
VIRTUALBOX_BUILD="105127"
PHPVIRTUALBOX_VER="5.0-5"
VIRTUALBOX_DOWNLOAD_URL="http://download.virtualbox.org/virtualbox/5.1.14/VirtualBox-5.1.14-112924-Linux_amd64.run"
VIRTUALBOX_DOWNLOAD_FILE="$(basename ${VIRTUALBOX_DOWNLOAD_URL})"
VIRTUALBOX_EXTENSIONPACK_DOWNLOAD_URL="http://download.virtualbox.org/virtualbox/5.1.14/Oracle_VM_VirtualBox_Extension_Pack-5.1.14-112924.vbox-extpack"
VIRTUALBOX_EXTENSIONPACK_DOWNLOAD_FILE="$(basename ${VIRTUALBOX_EXTENSIONPACK_DOWNLOAD_URL})"
VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_URL="https://sourceforge.net/projects/phpvirtualbox/files/phpvirtualbox-${PHPVIRTUALBOX_VER}.zip/download"
VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_FILE="$(getSourceForgeUriFilename $VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_URL)"
	
# Check if PHPVIRTUALBOX_VER is available, if not use the latest release
if [ -z "$VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_FILE" ]; then
	VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_URL="https://sourceforge.net/projects/phpvirtualbox/files/latest/download"
	VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_FILE="$(getSourceForgeUriFilename $VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_URL)"
	PHPVIRTUALBOX_VER=${VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_FILE#*-}
	PHPVIRTUALBOX_VER=${PHPVIRTUALBOX_VER%.*}
fi
	
# DSM language based messages
. "$(dirname $0)"/lang.sh
	
preinst ()
{
	# Nothing to be done here if we upgrade
	if [ "$SYNOPKG_PKG_STATUS" == "UPGRADE" ]; then
		exit 0
	fi
	
	# Check the DSM Version
	if [ ${DSMMAJOR} -gt 5 ]; then
		echo "$DSM_VERSION_ERROR"
		exit 1
	fi
	
	# check for supported kernel
	if [[ $KERNEL != "3.10.35" ]] || [[ $KERNEL != "3.2.40" && $DIST == "evansport" ]]; then
		echo "$KERNEL_ERROR"
		exit 1
	fi
	
	# check for loaded kernel module
	if [ "$LOADED_KERNEL_MODULE" ]; then
		echo "$KERNEL_LOADED_ERROR"
		exit 1
	fi
	
	#  Create a temp dir for the install files!
	[ ! -d "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}" ] && mkdir -p "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}"
	
	# Download VirtualBox
	wget "${VIRTUALBOX_DOWNLOAD_URL}" -P "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}"
	
	# Check if the download was successfully
	if [ ! -e "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_DOWNLOAD_FILE}" ]; then
		echo "$DOWNLOAD_ERROR"
		exit 1
	fi
	
	# Download VirtualBox ExtensionPacks
	wget "${VIRTUALBOX_EXTENSIONPACK_DOWNLOAD_URL}" -P "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}"
	
	# Check if the download was successfully
	if [ ! -e "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_EXTENSIONPACK_DOWNLOAD_FILE}" ]; then
		echo "$DOWNLOAD_ERROR_2"
		exit 1
	fi
	
	# Download PHPVirtualBox
	wget --content-disposition "${VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_URL}" -P "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}"
	
	# Check if the download was successfully
	if [ ! -e "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_FILE}" ]; then
		echo "$DOWNLOAD_ERROR_3"
		exit 1
	fi
	
	# Set the right permissions so that we can execute the VirtualBox file
	chmod 755 ${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_DOWNLOAD_FILE}
	
	# Execute the downloaded VirtualBox Version
	${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_DOWNLOAD_FILE} --noexec --keep --target ${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_DOWNLOAD_FILE%.*} > /dev/null 2>&1
	
	# Decompress VirtualBox
	tar -xjf "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_DOWNLOAD_FILE%.*}/VirtualBox.tar.bz2" -C "${SYNOPKG_PKGINST_TEMP_DIR}/opt/VirtualBox"
	
	if [ $? != 0 ]; then
		echo "$EXTRACT_ERROR"
		exit 1
	fi
	
	# Decompress VirtualBox ExtensionPacks
	tar -xzf "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_EXTENSIONPACK_DOWNLOAD_FILE}" -C "${SYNOPKG_PKGINST_TEMP_DIR}/opt/VirtualBox/ExtensionPacks/Oracle_VM_VirtualBox_Extension_Pack"
	
	if [ $? != 0 ]; then
		echo "$EXTRACT_ERROR_2"
		exit 1
	fi
	
	# Decompress phpvirtualbox
	unzip -q "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_FILE}" -d "${SYNOPKG_PKGINST_TEMP_DIR}/www"
	
	if [ $? != 0 ]; then
		echo "$EXTRACT_ERROR_3"
		exit 1
	fi
	
	# Delete the downloaded and decompressed files
	rm -fr ${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}
	
	exit 0
}
	
postinst ()
{
	# Nothing to be done here if we upgrade
	if [ "$SYNOPKG_PKG_STATUS" == "UPGRADE" ]; then
		exit 0
	fi
	
	# Remove old VirtualBox CFG file
	[ -d /etc/vbox ] && rm -fr /etc/vbox
		
	# Remove versions number from phpvirtualbox folder
	mv ${SYNOPKG_PKGDEST}/www/phpvirtualbox-${PHPVIRTUALBOX_VER} ${SYNOPKG_PKGDEST}/www/phpvirtualbox
	
	# check for libs
	[ ! -f "/lib/libz.so.1.2.8" ] && cp "${PACKAGE_DIR}"/target/lib/libz.so.1.2.8 /lib/
	[ ! -f "/lib64/libz.so.1.2.8" ] && cp "${PACKAGE_DIR}"/target/lib64/libz.so.1.2.8 /lib64/
	
	# create symlinks for libs
	[ ! -L "/lib/libz.so" ] && ln -s /lib/libz.so.1.2.8 /lib/libz.so
	[ ! -L "/lib/libz.so.1" ] && ln -s /lib/libz.so.1.2.8 /lib/libz.so.1
	[ ! -L "/lib64/libz.so" ] && ln -s /lib64/libz.so.1.2.8 /lib64/libz.so
	[ ! -L "/lib64/libz.so.1" ] && ln -s /lib64/libz.so.1.2.8 /lib64/libz.so.1
	
	# copy kernel module based on Synology model
	if [ $(echo $DIST | grep cedarview) ]; then
		if [ ! -f "/lib/modules/modules/${KERNEL}/vboxdrv.ko" ]; then
			cp -r "${PACKAGE_DIR}"/target/kernel_module/cedarview/${KERNEL} /lib/modules/
			touch ${PACKAGE_DIR}/${DIST}_${KERNEL}_cedarview
		fi
	elif [ $(echo $DIST | grep bromolow) ]; then
		if [ ! -f "/lib/modules/modules/${KERNEL}/vboxdrv.ko" ]; then
			cp -r "${PACKAGE_DIR}"/target/kernel_module/bromolow/${KERNEL} /lib/modules/
			touch ${PACKAGE_DIR}/${DIST}_${KERNEL}_bromolow
		fi
	elif [ $(echo $DIST | grep evansport) ]; then
		if [ ! -f "/lib/modules/modules/${KERNEL}/vboxdrv.ko" ]; then
			cp -r "${PACKAGE_DIR}"/target/kernel_module/evansport/${KERNEL} /lib/modules/
			touch ${PACKAGE_DIR}/${DIST}_${KERNEL}_evansport
		fi
	elif [ $(echo $DIST | grep avoton) ]; then
		if [ ! -f "/lib/modules/modules/${KERNEL}/vboxdrv.ko" ]; then
			cp -r "${PACKAGE_DIR}"/target/kernel_module/avoton/${KERNEL} /lib/modules/
			touch ${PACKAGE_DIR}/${DIST}_${KERNEL}_avoton
		fi
	elif [ $(echo $DIST | grep braswell) ]; then
		if [ ! -f "/lib/modules/modules/${KERNEL}/vboxdrv.ko" ]; then
			cp -r "${PACKAGE_DIR}"/target/kernel_module/braswell/${KERNEL} /lib/modules/
			touch ${PACKAGE_DIR}/${DIST}_${KERNEL}_braswell
		fi
	else
		if [ ! -f "/lib/modules/modules/${KERNEL}/vboxdrv.ko" ]; then
			cp -r "${PACKAGE_DIR}"/target/kernel_module/x86_64/${KERNEL} /lib/modules/
			touch ${PACKAGE_DIR}/${DIST}_${KERNEL}_x86_64
		fi
	fi
	
	# Link
	ln -s ${SYNOPKG_PKGDEST} ${INSTALL_DIR}
	
	# Install the phpVirtualBox web interface
	cp -pR ${INSTALL_DIR}/www/phpvirtualbox ${WEB_DIR}
	
	# Create a default configuration file for phpVirtualBox
	if [ ! -f ${CFG_FILE_PHPVB} ]; then
		cp ${DEFAULT_CFG_FILE_PHPVB} ${CFG_FILE_PHPVB}
		noAuth=$([ "${wizard_no_auth}" == "true" ] && echo "true" || echo "false")
		enableAdvancedConfig=$([ "${wizard_enable_advanced_config}" == "true" ] && echo "true" || echo "false")
		startStopConfig=$([ "${wizard_start_stop_config}" == "true" ] && echo "true" || echo "false")
		Language=$([ "${wizard_language_ger}" == "true" ] && echo "de" || echo "en")
		KeyboardLayout=$([ "${wizard_keyboard_layout_ger}" == "true" ] && echo "DE" || echo "EN")
		sed -i -e "s|@pass@|${wizard_vbox_pass:=}|g" ${CFG_FILE_PHPVB}
		sed -i -e "s|@noAuth@|${noAuth:=true}|g" ${CFG_FILE_PHPVB}
		sed -i -e "s|@enableAdvancedConfig@|${enableAdvancedConfig:=true}|g" ${CFG_FILE_PHPVB}
		sed -i -e "s|@startStopConfig@|${startStopConfig:=true}|g" ${CFG_FILE_PHPVB}
		sed -i -e "s|@language@|${Language}|g" ${CFG_FILE_PHPVB}
		sed -i -e "s|@keyboardlayout@|${KeyboardLayout}|g" ${CFG_FILE_PHPVB}
		chmod ga+w ${CFG_FILE_PHPVB}
	fi
	
	# Create a default configuration file for VirtualBox
	if [ ! -f ${CFG_FILE_VB} ]; then
		mkdir /etc/vbox
		cp ${DEFAULT_CFG_FILE_VB} ${CFG_FILE_VB}
		action="acpibutton"
		action=$([ "${wizard_on_stop_acpibutton}" == "true" ] && echo "acpibutton" || echo $action)
		action=$([ "${wizard_on_stop_savestate}" == "true" ] && echo "savestate" || echo $action)
		action=$([ "${wizard_on_stop_poweroff}" == "true" ] && echo "poweroff" || echo $action)
		sed -i -e "s|@shutdown@|${action}|g" ${CFG_FILE_VB}
	fi 
	
	[ -d "/root/.config/VirtualBox" ] && rm -fr /root/.config/VirtualBox
	
	if [ ! -d "/root/.config/VirtualBox" ]; then
		mkdir /root/.config/VirtualBox
		cp "${INSTALL_DIR}"/etc/VirtualBox-Config.xml /root/.config/VirtualBox/VirtualBox.xml
		sed -i -e "s|@virtualbox_path@|${wizard_virtualbox_path}|g" /root/.config/VirtualBox/VirtualBox.xml
	fi
	
	# Install vbox to /opt/VirtualBox
	[ ! -d /opt ] && mkdir /opt
	
	cp -pR "${INSTALL_DIR}/opt/VirtualBox" /opt/VirtualBox
	ln -s /opt/VirtualBox/additions /usr/share/virtualbox
	
	# Fix permissions
	chmod -R 755 /opt/VirtualBox
	
	chown -R root:root /opt/VirtualBox/ExtensionPacks
	
	exit 0
}
	
preuninst ()
{
	exit 0
}
	
postuninst ()
{
	# Remove link
	rm -f ${INSTALL_DIR}
	
	# Remove the web interface
	rm -fr ${WEB_DIR}/phpvirtualbox
	
	# Remove VirtualBox CFG file
	[ -d /etc/vbox ] && rm -fr /etc/vbox
	
	# Remove drivers
	if [ -f /lib/modules/${KERNEL}/vboxdrv.ko ]; then
		rm -f /lib/modules/${KERNEL}/modules.dep
		rm -f /lib/modules/${KERNEL}/vboxdrv.ko
		rm -f /lib/modules/${KERNEL}/vboxnetflt.ko
		rm -f /lib/modules/${KERNEL}/vboxnetadp.ko
		rm -f /lib/modules/${KERNEL}/vboxpci.ko
		if [ ! "$(ls -A /lib/modules/${KERNEL})" ]; then
			rmdir /lib/modules/${KERNEL}
		fi
	fi
	
	# Remove vbox
	if [ -d /opt/VirtualBox ]; then
		rm -fr /opt/VirtualBox
		rm -fr /usr/share/virtualbox
		if [ ! "$(ls -A /opt)" ]; then
			rmdir /opt
		fi
	fi
	
	# Remove the VirtualBox settings & logs
	[ -d /root/.config/VirtualBox ] && rm -fr /root/.config/VirtualBox
	
	exit 0
}

preupgrade ()
{
	# Check the DSM Version
	if [ ${DSMMAJOR} -gt 5 ]; then
		echo "$DSM_VERSION_ERROR"
		exit 1
	fi
	
	# check for supported kernel
	if [[ $KERNEL != "3.10.35" ]] || [[ $KERNEL != "3.2.40" && $DIST == "evansport" ]]; then
		echo "$KERNEL_ERROR"
		exit 1
	fi
	
	# check for loaded kernel module
	if [ "$LOADED_KERNEL_MODULE" ]; then
		echo "$KERNEL_LOADED_ERROR"
		exit 1
	fi
	
	#  Create a temp dir for the install files!
	[ ! -d "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}" ] && mkdir -p "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}"
	
	# Download VirtualBox
	wget "${VIRTUALBOX_DOWNLOAD_URL}" -P "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}"
	
	# Check if the download was successfully
	if [ ! -e "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_DOWNLOAD_FILE}" ]; then
		echo "$DOWNLOAD_ERROR"
		exit 1
	fi
	
	# Download VirtualBox ExtensionPacks
	wget "${VIRTUALBOX_EXTENSIONPACK_DOWNLOAD_URL}" -P "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}"
	
	# Check if the download was successfully
	if [ ! -e "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_EXTENSIONPACK_DOWNLOAD_FILE}" ]; then
		echo "$DOWNLOAD_ERROR_2"
		exit 1
	fi
	
	# Download PHPVirtualBox
	wget --content-disposition "${VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_URL}" -P "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}"
	
	# Check if the download was successfully
	if [ ! -e "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_FILE}" ]; then
		echo "$DOWNLOAD_ERROR_3"
		exit 1
	fi
	
	# Set the right permissions so that we can execute the VirtualBox file
	chmod 755 ${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_DOWNLOAD_FILE}
	
	# Execute the downloaded VirtualBox Version
	${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_DOWNLOAD_FILE} --noexec --keep --target ${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_DOWNLOAD_FILE%.*} > /dev/null 2>&1
	
	# Decompress VirtualBox
	tar -xjf "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_DOWNLOAD_FILE%.*}/VirtualBox.tar.bz2" -C "${SYNOPKG_PKGINST_TEMP_DIR}/opt/VirtualBox"
	
	if [ $? != 0 ]; then
		echo "$EXTRACT_ERROR"
		exit 1
	fi
	
	# Decompress VirtualBox ExtensionPacks
	tar -xzf "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_EXTENSIONPACK_DOWNLOAD_FILE}" -C "${SYNOPKG_PKGINST_TEMP_DIR}/opt/VirtualBox/ExtensionPacks/Oracle_VM_VirtualBox_Extension_Pack"
	
	if [ $? != 0 ]; then
		echo "$EXTRACT_ERROR_2"
		exit 1
	fi
	
	# Decompress phpvirtualbox
	unzip -q "${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}/${VIRTUALBOX_PHPVIRTUALBOX_DOWNLOAD_FILE}" -d "${SYNOPKG_PKGINST_TEMP_DIR}/www"
	
	if [ $? != 0 ]; then
		echo "$EXTRACT_ERROR_3"
		exit 1
	fi
	
	# Delete the downloaded and decompressed files
	rm -fr ${SYNOPKG_PKGINST_TEMP_DIR}/${INSTALL_FILES}
	
	# When upgrading, we need to backup the config files into a temporary dir!
	[ ! -d "${SYNOPKG_PKGINST_TEMP_DIR}/${BACKUP_FILES}" ] && mkdir -p "${SYNOPKG_PKGINST_TEMP_DIR}/${BACKUP_FILES}"
	
	# Save some stuff
	#rm -fr ${SYNOPKG_PKGINST_TEMP_DIR}/${BACKUP_FILES}
	mkdir -p ${SYNOPKG_PKGINST_TEMP_DIR}/${BACKUP_FILES}
	mv ${CFG_FILE_PHPVB} ${SYNOPKG_PKGINST_TEMP_DIR}/${BACKUP_FILES}/
	mv /root/.config/VirtualBox ${SYNOPKG_PKGINST_TEMP_DIR}/${BACKUP_FILES}/
	
	exit 0
}

postupgrade ()
{
	# Remove old VirtualBox CFG file
	[ -d /etc/vbox ] && rm -fr /etc/vbox
		
	# Remove versions number from phpvirtualbox folder
	mv ${SYNOPKG_PKGDEST}/www/phpvirtualbox-${PHPVIRTUALBOX_VER} ${SYNOPKG_PKGDEST}/www/phpvirtualbox
	
	# check for libs
	[ ! -f "/lib/libz.so.1.2.8" ] && cp "${PACKAGE_DIR}"/target/lib/libz.so.1.2.8 /lib/
	[ ! -f "/lib64/libz.so.1.2.8" ] && cp "${PACKAGE_DIR}"/target/lib64/libz.so.1.2.8 /lib64/
	
	# create symlinks for libs
	[ ! -L "/lib/libz.so" ] && ln -s /lib/libz.so.1.2.8 /lib/libz.so
	[ ! -L "/lib/libz.so.1" ] && ln -s /lib/libz.so.1.2.8 /lib/libz.so.1
	[ ! -L "/lib64/libz.so" ] && ln -s /lib64/libz.so.1.2.8 /lib64/libz.so
	[ ! -L "/lib64/libz.so.1" ] && ln -s /lib64/libz.so.1.2.8 /lib64/libz.so.1
	
	# copy kernel module based on Synology model
	if [ $(echo $DIST | grep cedarview) ]; then
		if [ ! -f "/lib/modules/modules/${KERNEL}/vboxdrv.ko" ]; then
			cp -r "${PACKAGE_DIR}"/target/kernel_module/cedarview/${KERNEL} /lib/modules/
			touch ${PACKAGE_DIR}/${DIST}_${KERNEL}_cedarview
		fi
	elif [ $(echo $DIST | grep bromolow) ]; then
		if [ ! -f "/lib/modules/modules/${KERNEL}/vboxdrv.ko" ]; then
			cp -r "${PACKAGE_DIR}"/target/kernel_module/bromolow/${KERNEL} /lib/modules/
			touch ${PACKAGE_DIR}/${DIST}_${KERNEL}_bromolow
		fi
	elif [ $(echo $DIST | grep evansport) ]; then
		if [ ! -f "/lib/modules/modules/${KERNEL}/vboxdrv.ko" ]; then
			cp -r "${PACKAGE_DIR}"/target/kernel_module/evansport/${KERNEL} /lib/modules/
			touch ${PACKAGE_DIR}/${DIST}_${KERNEL}_evansport
		fi
	elif [ $(echo $DIST | grep avoton) ]; then
		if [ ! -f "/lib/modules/modules/${KERNEL}/vboxdrv.ko" ]; then
			cp -r "${PACKAGE_DIR}"/target/kernel_module/avoton/${KERNEL} /lib/modules/
			touch ${PACKAGE_DIR}/${DIST}_${KERNEL}_avoton
		fi
	elif [ $(echo $DIST | grep braswell) ]; then
		if [ ! -f "/lib/modules/modules/${KERNEL}/vboxdrv.ko" ]; then
			cp -r "${PACKAGE_DIR}"/target/kernel_module/braswell/${KERNEL} /lib/modules/
			touch ${PACKAGE_DIR}/${DIST}_${KERNEL}_braswell
		fi
	else
		if [ ! -f "/lib/modules/modules/${KERNEL}/vboxdrv.ko" ]; then
			cp -r "${PACKAGE_DIR}"/target/kernel_module/x86_64/${KERNEL} /lib/modules/
			touch ${PACKAGE_DIR}/${DIST}_${KERNEL}_x86_64
		fi
	fi
	
	# Link
	ln -s ${SYNOPKG_PKGDEST} ${INSTALL_DIR}
	
	# Install the phpVirtualBox web interface
	cp -pR ${INSTALL_DIR}/www/phpvirtualbox ${WEB_DIR}
	
	# Create a default configuration file for VirtualBox
	if [ ! -f ${CFG_FILE_VB} ]; then
		mkdir /etc/vbox
		cp ${DEFAULT_CFG_FILE_VB} ${CFG_FILE_VB}
		action="acpibutton"
		action=$([ "${wizard_on_stop_acpibutton}" == "true" ] && echo "acpibutton" || echo $action)
		action=$([ "${wizard_on_stop_savestate}" == "true" ] && echo "savestate" || echo $action)
		action=$([ "${wizard_on_stop_poweroff}" == "true" ] && echo "poweroff" || echo $action)
		sed -i -e "s|@shutdown@|${action}|g" ${CFG_FILE_VB}
	fi 
	
	# Install vbox to /opt/VirtualBox
	[ ! -d /opt ] && mkdir /opt
	
	cp -pR "${INSTALL_DIR}/opt/VirtualBox" /opt/VirtualBox
	ln -s /opt/VirtualBox/additions /usr/share/virtualbox
	
	# Fix permissions
	chmod -R 755 /opt/VirtualBox
	
	chown -R root:root /opt/VirtualBox/ExtensionPacks
	
	# Restore some stuff
	rm -f ${CFG_FILE_PHPVB}
	rm -fr /root/.config/VirtualBox
	mv ${SYNOPKG_PKGDEST}/${BACKUP_FILES}/VirtualBox /root/.config/
	mv ${SYNOPKG_PKGDEST}/${BACKUP_FILES}/config.php ${CFG_FILE_PHPVB}
	rm -fr ${SYNOPKG_PKGDEST}/${BACKUP_FILES}
	
	# Set VirtualBox VMs path
	if [ -f /root/.config/VirtualBox/VirtualBox.xml ]; then
		VIRTUAL_BOX_PATH=$(cat "/root/.config/VirtualBox/VirtualBox.xml" | grep "defaultMachineFolder")
		PATTERN=$(echo $VIRTUAL_BOX_PATH | awk -F '"' '{ print $2}')
		PATTERN="defaultMachineFolder=\"$PATTERN\""
		VIRTUAL_BOX_PATH_NEW="defaultMachineFolder=\"${wizard_virtualbox_path}\""
		echo $VIRTUAL_BOX_PATH | sed -i -e "s|$PATTERN|$VIRTUAL_BOX_PATH_NEW|g" /root/.config/VirtualBox/VirtualBox.xml
	fi
	
	exit 0
}
