export VIRTUALBOX_SSH_USER=docker
export VIRTUALBOX_SSH_PASSWORD=passwd
export VIRTUALBOX_BOOT2DOCKER_URL='http://192.168.168.2/boot2docker.iso'
docker-machine create -d virtualbox \
--engine-registry-mirror=http://77f86377.m.daocloud.io \
--engine-registry-mirror=https://docker.mirrors.ustc.edu.cn \
--engine-insecure-registry='http://*.lockyse7en.com:*' \
--engine-insecure-registry='http://192.168.168.0/24:*' \
--engine-insecure-registry='localhost:*' \
--virtualbox-cpu-count=2 --virtualbox-memory=4096  \
--virtualbox-import-boot2docker-vm boot2docker-vm default

export VSPHERE_BOOT2DOCKER_URL='http://192.168.168.2/boot2docker.iso'
export VSPHERE_VCENTER='192.168.168.168'
export VSPHERE_USERNAME='root'
export VSPHERE_PASSWORD='fc123@@@'
export VSPHERE_NETWORK='VM0'
export VSPHERE_DISKSIZE='20480'
export VSPHERE_DATASTORE='datastore1'
docker-machine create -d vmwarevsphere \
--insecure-registry=http://192.168.168.2:4443 \
--engine-registry-mirror=http://77f86377.m.daocloud.io \
--engine-registry-mirror=https://docker.mirrors.ustc.edu.cn default