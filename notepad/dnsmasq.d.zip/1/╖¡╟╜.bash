https://raw.githubusercontent.com/kgfw/fg/master/ios/ios.pac
sudo sed -i "s|EXTRA_ARGS='|EXTRA_ARGS='--registry-mirror=地 |g" /var/lib/boot2docker/profile
exit

‘--registry-mirrors=https://docker.mirrors.ustc.edu.cn,http://77f86377.m.daocloud.io,http://hub.c.163.com