#!/bin/bash
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH

clear;
# Logo 	******************************************************************
CopyrightLogo='
                         DS Video Douban Patch v201703101447                                  
                                    by atroy 2017                     
                         http://9hut.com All Rights Reserved                  
                                                                            
==========================================================================';
echo "$CopyrightLogo";

# SHELL 	******************************************************************
cd /tmp/;

mv -f /var/packages/VideoStation/target/plugins/syno_themoviedb/search.php /var/packages/VideoStation/target/plugins/syno_themoviedb/search.php.orig
mv -f /var/packages/VideoStation/target/plugins/syno_synovideodb/search.php /var/packages/VideoStation/target/plugins/syno_synovideodb/search.php.orig
mv -f /var/packages/VideoStation/target/ui/videostation2.js /var/packages/VideoStation/target/ui/videostation2.js.orig

wget http://sh.9hut.cn/files/video_station_douban_patch.dat -O video_station_douban_patch.tar;
tar -xvf video_station_douban_patch.tar

\cp -rfa ./syno_themoviedb /var/packages/VideoStation/target/plugins/;
\cp -rfa ./syno_synovideodb /var/packages/VideoStation/target/plugins/;
\cp -rfa ./ui /var/packages/VideoStation/target/;

chmod 0755 /var/packages/VideoStation/target/plugins/syno_themoviedb/search.php
chmod 0755 /var/packages/VideoStation/target/plugins/syno_synovideodb/search.php
chmod 0755 /var/packages/VideoStation/target/ui/videostation2.js

chown VideoStation:VideoStation /var/packages/VideoStation/target/plugins/syno_themoviedb/search.php
chown VideoStation:VideoStation /var/packages/VideoStation/target/plugins/syno_synovideodb/search.php
chown VideoStation:VideoStation /var/packages/VideoStation/target/ui/videostation2.js

cd -
rm -rf dsvp.sh

echo '==========================================================================';
echo 'Congratulations, DS Video Douban Patch v201703101447 install completed.';
echo '==========================================================================';

