FROM boot2docker/boot2docker:1.11.2


RUN rm -rf /rootfs/usr/local/etc/init.d/docker
 
COPY   $roots/rootfs/usr/local/etc/init.d/docker  /rootfs/usr/local/etc/init.d/docker

COPY $rootfs/rootfs/usr/bin/lantern  /rootfs/rootfs/usr/bin/lantern

COPY $rootfs/rootfs/usr

RUN chmod +x /rootfs/rootfs/usr/bin/lantern

RUN curl -L https://get.daocloud.io/docker/compose/releases/download/1.12.2/docker-compose-`uname -s`-`uname -m` > /rootfs/usr/local/bin/docker-compose

RUN chmod +x /rootfs/usr/local/bin/docker-compose

# make data 

RUN mkdir /rootfs/data /rootfs/data/registry /rootfs/data/database /rootfs/data/job_logs

RUN wget http://192.168.168.2/boot2docker/harbor-online-installer-0.5.0.tgz

RUN tar -xzvf harbor-online-installer-0.5.0.tgz

RUN mv harbor  /rootfs/

RUN  cd /rootfs/harbor

RUN rm -rf harbor.cfg

RUN wget http://192.168.168.2/harbor.cfg

RUN wget http://192.168.168.2/cert.tar.gz

RUN tar -xvzf cert.tar.gz

RUN ./prepare

RUN /tmp/make_iso.sh

CMD ["cat", "boot2docker.iso"]
