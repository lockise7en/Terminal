#ssh-keygen -t rsa -b 4096 -C "lockyse7en@outlook.com"
eval $(ssh-agent -s)
ssh-add ~/.ssh/id_rsa
clip < ~/.ssh/id_rsa.pub
ssh -T git@github.com