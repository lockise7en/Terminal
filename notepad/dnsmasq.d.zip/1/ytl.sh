# docker pull microsoft/vsts-agent
# docker pull microsoft/azure-cli
# docker pull microsoft/iis
# docker pull microsoft/aspnetcore-build
# docker pull microsoft/aspnet
# docker pull microsoft/mssql-server-linux
# docker pull microsoft/nanoserver
# docker pull microsoft/windowsservercore
# docker pull microsoft/aspnetcore
# docker pull microsoft/applicationinsights
# docker pull microsoft/dotnet-nightly
# docker pull microsoft/dotnet-buildtools-prereqs
# docker pull microsoft/dotnet-samples
# docker pull microsoft/draft
# docker pull microsoft/sample-nginx
# docker pull microsoft/mssql-server-windows-express
# docker pull microsoft/mssql-server-windows
# docker pull microsoft/dotnet-framework
docker pull microsoft/powershell
docker pull microsoft/mssql-server-windows-developer
docker pull microsoft/aspnetcore-build-nightly
docker pull microsoft/cntk
docker pull microsoft/dotnet-framework-samples
docker pull microsoft/iot-gateway-opc-ua-proxy
docker pull microsoft/iot-gateway-opc-ua
docker pull microsoft/sample-http
docker pull microsoft/powershell-nightly
docker pull microsoft/azure-vote-back
docker pull microsoft/azure-documentdb-emulator
docker pull microsoft/sample-mysql
docker pull microsoft/sample-node
docker pull microsoft/meta-azure-service-broker
docker pull microsoft/azure-cosmosdb-emulator
docker pull microsoft/aspnetcore-nightly
docker pull microsoft/sqlite
docker pull microsoft/mmlspark
docker pull microsoft/sample-ruby
docker pull microsoft/sample-rails
docker pull microsoft/nanoserver-insider-dotnet
docker pull microsoft/wcf
docker pull microsoft/azure-vote-front
docker pull microsoft/mssql-monitoring-collectd
docker pull microsoft/nanoserver-insider
docker tag microsoft/vsts-agent lockyse7en.com/microsoft/vsts-agent
docker tag microsoft/azure-cli lockyse7en.com/microsoft/azure-cli
docker tag microsoft/iis lockyse7en.com/microsoft/iis
docker tag microsoft/aspnetcore-build lockyse7en.com/microsoft/aspnetcore-build
docker tag microsoft/aspnet lockyse7en.com/microsoft/aspnet
docker tag microsoft/mssql-server-linux lockyse7en.com/microsoft/mssql-server-linux
docker tag microsoft/nanoserver lockyse7en.com/microsoft/nanoserver
docker tag microsoft/windowsservercore lockyse7en.com/microsoft/windowsservercore
docker tag microsoft/aspnetcore lockyse7en.com/microsoft/aspnetcore
docker tag microsoft/applicationinsights lockyse7en.com/microsoft/applicationinsights
docker tag microsoft/dotnet-nightly lockyse7en.com/microsoft/dotnet-nightly
docker tag microsoft/dotnet-buildtools-prereqs lockyse7en.com/microsoft/dotnet-buildtools-prereqs
docker tag microsoft/dotnet-samples lockyse7en.com/microsoft/dotnet-samples
docker tag microsoft/draft lockyse7en.com/microsoft/draft
docker tag microsoft/sample-nginx lockyse7en.com/microsoft/sample-nginx
docker tag microsoft/mssql-server-windows-express lockyse7en.com/microsoft/mssql-server-windows-express
docker tag microsoft/mssql-server-windows lockyse7en.com/microsoft/mssql-server-windows
docker tag microsoft/dotnet-framework lockyse7en.com/microsoft/dotnet-framework
docker tag microsoft/powershell lockyse7en.com/microsoft/powershell
docker tag microsoft/mssql-server-windows-developer lockyse7en.com/microsoft/mssql-server-windows-developer
docker tag microsoft/aspnetcore-build-nightly lockyse7en.com/microsoft/aspnetcore-build-nightly
docker tag microsoft/cntk lockyse7en.com/microsoft/cntk
docker tag microsoft/dotnet-framework-samples lockyse7en.com/microsoft/dotnet-framework-samples
docker tag microsoft/iot-gateway-opc-ua-proxy lockyse7en.com/microsoft/iot-gateway-opc-ua-proxy
docker tag microsoft/iot-gateway-opc-ua lockyse7en.com/microsoft/iot-gateway-opc-ua
docker tag microsoft/sample-http lockyse7en.com/microsoft/sample-http
docker tag microsoft/powershell-nightly lockyse7en.com/microsoft/powershell-nightly
docker tag microsoft/azure-vote-back lockyse7en.com/microsoft/azure-vote-back
docker tag microsoft/azure-documentdb-emulator lockyse7en.com/microsoft/azure-documentdb-emulator
docker tag microsoft/sample-mysql lockyse7en.com/microsoft/sample-mysql
docker tag microsoft/sample-node lockyse7en.com/microsoft/sample-node
docker tag microsoft/meta-azure-service-broker lockyse7en.com/microsoft/meta-azure-service-broker
docker tag microsoft/azure-cosmosdb-emulator lockyse7en.com/microsoft/azure-cosmosdb-emulator
docker tag microsoft/aspnetcore-nightly lockyse7en.com/microsoft/aspnetcore-nightly
docker tag microsoft/sqlite lockyse7en.com/microsoft/sqlite
docker tag microsoft/mmlspark lockyse7en.com/microsoft/mmlspark
docker tag microsoft/sample-ruby lockyse7en.com/microsoft/sample-ruby
docker tag microsoft/sample-rails lockyse7en.com/microsoft/sample-rails
docker tag microsoft/nanoserver-insider-dotnet lockyse7en.com/microsoft/nanoserver-insider-dotnet
docker tag microsoft/wcf lockyse7en.com/microsoft/wcf
docker tag microsoft/azure-vote-front lockyse7en.com/microsoft/azure-vote-front
docker tag microsoft/mssql-monitoring-collectd lockyse7en.com/microsoft/mssql-monitoring-collectd
docker tag microsoft/nanoserver-insider lockyse7en.com/microsoft/nanoserver-insider
docker push lockyse7en.com/microsoft/vsts-agent
docker push lockyse7en.com/microsoft/azure-cli
docker push lockyse7en.com/microsoft/iis
docker push lockyse7en.com/microsoft/aspnetcore-build
docker push lockyse7en.com/microsoft/aspnet
docker push lockyse7en.com/microsoft/mssql-server-linux
docker push lockyse7en.com/microsoft/nanoserver
docker push lockyse7en.com/microsoft/windowsservercore
docker push lockyse7en.com/microsoft/aspnetcore
docker push lockyse7en.com/microsoft/applicationinsights
docker push lockyse7en.com/microsoft/dotnet-nightly
docker push lockyse7en.com/microsoft/dotnet-buildtools-prereqs
docker push lockyse7en.com/microsoft/dotnet-samples
docker push lockyse7en.com/microsoft/draft
docker push lockyse7en.com/microsoft/sample-nginx
docker push lockyse7en.com/microsoft/mssql-server-windows-express
docker push lockyse7en.com/microsoft/mssql-server-windows
docker push lockyse7en.com/microsoft/dotnet-framework
docker push lockyse7en.com/microsoft/powershell
docker push lockyse7en.com/microsoft/mssql-server-windows-developer
docker push lockyse7en.com/microsoft/aspnetcore-build-nightly
docker push lockyse7en.com/microsoft/cntk
docker push lockyse7en.com/microsoft/dotnet-framework-samples
docker push lockyse7en.com/microsoft/iot-gateway-opc-ua-proxy
docker push lockyse7en.com/microsoft/iot-gateway-opc-ua
docker push lockyse7en.com/microsoft/sample-http
docker push lockyse7en.com/microsoft/powershell-nightly
docker push lockyse7en.com/microsoft/azure-vote-back
docker push lockyse7en.com/microsoft/azure-documentdb-emulator
docker push lockyse7en.com/microsoft/sample-mysql
docker push lockyse7en.com/microsoft/sample-node
docker push lockyse7en.com/microsoft/meta-azure-service-broker
docker push lockyse7en.com/microsoft/azure-cosmosdb-emulator
docker push lockyse7en.com/microsoft/aspnetcore-nightly
docker push lockyse7en.com/microsoft/sqlite
docker push lockyse7en.com/microsoft/mmlspark
docker push lockyse7en.com/microsoft/sample-ruby
docker push lockyse7en.com/microsoft/sample-rails
docker push lockyse7en.com/microsoft/nanoserver-insider-dotnet
docker push lockyse7en.com/microsoft/wcf
docker push lockyse7en.com/microsoft/azure-vote-front
docker push lockyse7en.com/microsoft/mssql-monitoring-collectd
docker push lockyse7en.com/microsoft/nanoserver-insider
docker rmi lockyse7en.com/microsoft/vsts-agent
docker rmi lockyse7en.com/microsoft/azure-cli
docker rmi lockyse7en.com/microsoft/iis
docker rmi lockyse7en.com/microsoft/aspnetcore-build
docker rmi lockyse7en.com/microsoft/aspnet
docker rmi lockyse7en.com/microsoft/mssql-server-linux
docker rmi lockyse7en.com/microsoft/nanoserver
docker rmi lockyse7en.com/microsoft/windowsservercore
docker rmi lockyse7en.com/microsoft/aspnetcore
docker rmi lockyse7en.com/microsoft/applicationinsights
docker rmi lockyse7en.com/microsoft/dotnet-nightly
docker rmi lockyse7en.com/microsoft/dotnet-buildtools-prereqs
docker rmi lockyse7en.com/microsoft/dotnet-samples
docker rmi lockyse7en.com/microsoft/draft
docker rmi lockyse7en.com/microsoft/sample-nginx
docker rmi lockyse7en.com/microsoft/mssql-server-windows-express
docker rmi lockyse7en.com/microsoft/mssql-server-windows
docker rmi lockyse7en.com/microsoft/dotnet-framework
docker rmi lockyse7en.com/microsoft/powershell
docker rmi lockyse7en.com/microsoft/mssql-server-windows-developer
docker rmi lockyse7en.com/microsoft/aspnetcore-build-nightly
docker rmi lockyse7en.com/microsoft/cntk
docker rmi lockyse7en.com/microsoft/dotnet-framework-samples
docker rmi lockyse7en.com/microsoft/iot-gateway-opc-ua-proxy
docker rmi lockyse7en.com/microsoft/iot-gateway-opc-ua
docker rmi lockyse7en.com/microsoft/sample-http
docker rmi lockyse7en.com/microsoft/powershell-nightly
docker rmi lockyse7en.com/microsoft/azure-vote-back
docker rmi lockyse7en.com/microsoft/azure-documentdb-emulator
docker rmi lockyse7en.com/microsoft/sample-mysql
docker rmi lockyse7en.com/microsoft/sample-node
docker rmi lockyse7en.com/microsoft/meta-azure-service-broker
docker rmi lockyse7en.com/microsoft/azure-cosmosdb-emulator
docker rmi lockyse7en.com/microsoft/aspnetcore-nightly
docker rmi lockyse7en.com/microsoft/sqlite
docker rmi lockyse7en.com/microsoft/mmlspark
docker rmi lockyse7en.com/microsoft/sample-ruby
docker rmi lockyse7en.com/microsoft/sample-rails
docker rmi lockyse7en.com/microsoft/nanoserver-insider-dotnet
docker rmi lockyse7en.com/microsoft/wcf
docker rmi lockyse7en.com/microsoft/azure-vote-front
docker rmi lockyse7en.com/microsoft/mssql-monitoring-collectd
docker rmi lockyse7en.com/microsoft/nanoserver-insider
