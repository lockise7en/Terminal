echo "deb ftp://lockyse7en.com/ubuntu/ xenial main restricted universe multiverse" > /etc/apt/sources.list && \
        echo "deb ftp://lockyse7en.com/ubuntu/ xenial-updates main restricted universe multiverse" >> /etc/apt/sources.list && \
        echo "deb ftp://lockyse7en.com/ubuntu/ xenial-backports main restricted universe multiverse" >> /etc/apt/sources.list && \
        echo "deb ftp://lockyse7en.com/ubuntu/ xenial-security main restricted universe multiverse" >> /etc/apt/sources.list
echo "deb file://mirrors/ubuntu/ xenial main restricted universe multiverse" > /etc/apt/sources.list && \
        echo "deb file://mirrors/ubuntu/ xenial-updates main restricted universe multiverse" >> /etc/apt/sources.list && \
        echo "deb file://mirrors/ubuntu/ xenial-backports main restricted universe multiverse" >> /etc/apt/sources.list && \
        echo "deb file://mirrors/ubuntu/ xenial-security main restricted universe multiverse" >> /etc/apt/sources.list
echo "deb http://127.0.0.1/ubuntu/ xenial main restricted universe multiverse" > /etc/apt/sources.list && \
        echo "deb http://127.0.0.1/ubuntu/ xenial-updates main restricted universe multiverse" >> /etc/apt/sources.list && \
        echo "deb http://127.0.0.1/ubuntu/ xenial-backports main restricted universe multiverse" >> /etc/apt/sources.list && \
        echo "deb http://127.0.0.1/ubuntu/ xenial-security main restricted universe multiverse" >> /etc/apt/sources.list