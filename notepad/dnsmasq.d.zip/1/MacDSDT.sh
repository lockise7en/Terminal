#/bin/bash

# Step.1
mkdir ~/Projects
cd ~/Projects
git clone https://github.com/RehabMan/Lenovo-Y50-DSDT-Patch y50.git

# Step.2
cd ~/Projects/y50.git
./download.sh
./install_downloads.sh

# Step.3
cd ~/Projects/y50.git
make
make install

# Step.4
cd ~/Projects/y50.git
curl -o ./ssdtPRGen.sh https://raw.githubusercontent.com/Piker-Alpha/ssdtPRGen.sh/master/ssdtPRGen.sh
chmod +x ./ssdtPRGen.sh

# Step.5
./ssdtPRGen.sh

# Step.6
cd ~/Projects/y50.git
sudo ./mount_efi.sh /
cp ~/Library/ssdtPRGen/ssdt.aml /Volumes/EFI/EFI/Clover/ACPI/patched/SSDT.aml

# Step.7
cd ~/Projects/y50.git
sudo ./mount_efi.sh /

# Step.8
cd ~/Projects/y50.git
cp config.plist /Volumes/EFI/EFI/Clover/config.plist