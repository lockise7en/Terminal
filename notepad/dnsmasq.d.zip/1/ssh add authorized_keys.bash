$1=.ssh
$2=authorized_keys
if test ! -e $1;
then mkdir $1;
chmod 700 $1;
fi;
if test ! -e "$1/$2";
then touch "$1/$2";
chmod 600 "$1/$2";
fi;
echo $3 >> "$1/$2";